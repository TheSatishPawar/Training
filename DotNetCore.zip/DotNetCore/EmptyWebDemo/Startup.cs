﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.IO;
using Microsoft.Extensions.FileProviders;

namespace EmptyWebDemo
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

/*
            //first middleware
            app.Use(async (context, next) =>
            {
                await context.Response.WriteAsync("From First Middleware");
                await next.Invoke();
                await context.Response.WriteAsync("From First Middleware");

            });


            //middle ware for /about route (only for about route)
            app.Map(new PathString("/about"), (appbuilder) =>
            {
                appbuilder.Use(async (context, next) =>
                {
                    await context.Response.WriteAsync("From Second Middleware");
                    await next.Invoke();
                    await context.Response.WriteAsync("From Third Middleware");

                });
                appbuilder.Run(async (context) =>
                           {
                               await context.Response.WriteAsync("About Page");
                           });
            });




//Query Middleware
app.MapWhen((context)=>context.Request.Query.ContainsKey("id"),(appbuilder)=>{
    appbuilder.Use(async (context, next) =>
                {
                    await context.Response.WriteAsync("From Query Middleware");
                    await next.Invoke();
                    await context.Response.WriteAsync("From Query Middleware");

                });
                appbuilder.Run(async (context) =>
                           {
                               await context.Response.WriteAsync("Page With ID ");
                           });
});

*/

/*
//custom Middleware Call
app.UseMiddleware<MyCustomMiddleware>();
 */


//Custom file access inside wwwroot
DefaultFilesOptions options= new DefaultFilesOptions();
options.DefaultFileNames.Clear();
options.DefaultFileNames.Add("test.html");
app.UseDefaultFiles(options);


 app.UseDefaultFiles(); //use default files like index.html

app.UseStaticFiles(); //For static files like css, js, images, ect.

//For Custom folder which is outside of wwwroot folder
// app.UseStaticFiles(new StaticFileOptions(){
//     FileProvider= new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(),"StaticFileFolder")),
//     RequestPath="/staticfiles" //url folder name or any name
// });

//Directory middleware
app.UseDirectoryBrowser(new DirectoryBrowserOptions(){
FileProvider=new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(),"wwwroot","images")),
RequestPath="/images"
});

//use for both static files and Directory access
app.UseFileServer(new FileServerOptions(){
    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(),"StaticFileFolder")),
    RequestPath="/files",
    EnableDirectoryBrowsing=true
    });

//custom Middleware call with extension method
 app.UseMyCustomMiddleware();

            app.Run(async (context) =>
            {
                await context.Response.WriteAsync("Hello World! <br/>");
            });
        }
    }
}
