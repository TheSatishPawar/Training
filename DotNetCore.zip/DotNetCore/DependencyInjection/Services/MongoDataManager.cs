using System;
using System.Collections.Generic;
using System.Linq;

namespace Services
{
    public class MongoDataManager:IDataManager
    {
        public string GetMessage()
        {
            return "From Mongo Data Manager";
        }
    }
}