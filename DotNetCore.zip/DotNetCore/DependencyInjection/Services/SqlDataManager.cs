using System;
using System.Collections.Generic;
using System.Linq;

namespace Services
{
    public class SqlDataManager:IDataManager
    {
        public string GetMessage()
        {
            return "From Sql Data Manager";
        }
    }
}