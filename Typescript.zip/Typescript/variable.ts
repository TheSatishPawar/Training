var a=10;

let b=20;

function dosome()
{
    for(let i=0; i<5; i++){
console.log(i);
    }

    //console.log('out '+i); --error
}

dosome();