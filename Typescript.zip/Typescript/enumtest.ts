enum ColorDemo {
    Red,
    Green,
    Blue
}

// To String
var green: string = ColorDemo[ColorDemo.Green];

// To Enum
var color : ColorDemo = ColorDemo[green];

console.log(a);