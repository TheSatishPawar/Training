export  class calculator{
    public getArea(length:number,breath:number):number{
        return length * breath;
    }
}