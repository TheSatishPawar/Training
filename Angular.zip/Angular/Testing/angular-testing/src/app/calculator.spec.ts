import {calculator} from './calculator';

describe('calulator validation',()=>{
    it('Area is equal to 100',()=>{
        //Arrange
        let cal:calculator = new calculator();

        //Act
        const acturalArea=cal.getArea(50,2);

        //Assert
        const expeectedArea =100;

        expect(acturalArea).toBe(expeectedArea);
    });


    it('Area is equal to 200',()=>{
        let cal:calculator = new calculator();

        const actualResult = cal.getArea(50,3);

        const expectedResult=200;

        expect(actualResult).toEqual(expectedResult);
    })
})