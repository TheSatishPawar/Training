export class User{
    constructor(
        public userName: string,
        public phone: number,
        public email: string,
        public city:string,
        public gender:string,
        public subscribe: boolean
    ){}
}