export interface Product{
     pid: number;
     pname:string;
     price:number;
     image:string;    
}