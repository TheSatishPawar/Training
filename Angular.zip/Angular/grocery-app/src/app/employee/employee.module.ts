import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { ListComponent } from './list/list.component';
import { Routes, RouterModule } from '@angular/router';
import { PagenotfoundComponent } from '../shared/pagenotfound/pagenotfound.component';

const routes: Routes=[
{path:'add',component:AddComponent},
{path:'edit',component:EditComponent},
{path:'delete',component:DeleteComponent},
{path:'list',component:ListComponent},
{path:'**',component:PagenotfoundComponent},  
]

@NgModule({
  declarations: [AddComponent, EditComponent, DeleteComponent, ListComponent],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
})
export class EmployeeModule { }
