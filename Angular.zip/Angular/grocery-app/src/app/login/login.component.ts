import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  rForm: FormGroup;
  userLogin:any;
  username: string='';
  password: string ='';
  errorMessage: string='';

  constructor(private fb:FormBuilder) { 
   this.onFormCreate();
  }

  ngOnInit() {
  }

onFormCreate()
{
  this.rForm=this.fb.group({
    'username':[this.username,Validators.required],
    'password': [this.password,Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(10)])]
  })
}

onSubmit(data)
{
  //localStorage.setItem('user',JSON.stringify(this.rForm.value));
  if(this.rForm.value.username=='admin' && this.rForm.value.password=='password')
localStorage.setItem('isLoggedIn',JSON.stringify(this.rForm.value));
else
this.errorMessage='Invalid Username and Password';
}

}
