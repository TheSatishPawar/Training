import { Pipe, PipeTransform } from '@angular/core';
import { elementStyleProp } from '@angular/core/src/render3';

@Pipe({
  name: 'title'
})
export class TitlePipe implements PipeTransform {

  transform(value: any, gender:string): any {
    if(gender=='Male')
    return 'Mr. ' + value;
    else
    return 'Mrs. ' + value;
  }

}
