import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

public message="Data send by parent component";

public childData:any;

  constructor() { }

  ngOnInit() {
  }

  sendToChild(){
    console.log('log');
    this.message='Send to child';
  }

}
