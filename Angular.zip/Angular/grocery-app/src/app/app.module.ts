import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { CategoryComponent } from './category/category.component';
import { HomeComponent } from './home/home.component';
import { StructureComponent } from './structure/structure.component';
import { TopComponent } from './shared/top/top.component';
import { TitlePipe } from './title.pipe';
import { ParentComponent } from './parentchild/parent/parent.component';
import { ChildComponent } from './parentchild/child/child.component';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './shared/pagenotfound/pagenotfound.component';
import { ProductsComponent } from './products/products.component';
import { ProductsItemComponent } from './products-item/products-item.component';

import {HttpClient,HttpClientModule} from '@angular/common/http';

import {ToastrModule} from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    NavbarComponent,
    HeaderComponent,
    FooterComponent,
    CategoryComponent,
    HomeComponent,
    StructureComponent,
    TopComponent,
    TitlePipe,
    ParentComponent,
    ChildComponent,
    RegisterComponent,
    LoginComponent,
    PagenotfoundComponent,
    ProductsComponent,
    ProductsItemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
