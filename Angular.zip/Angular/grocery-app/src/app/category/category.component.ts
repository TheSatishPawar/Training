import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { DataService } from '../_services/data.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
categories=[];
  constructor(private router: Router, private data:DataService) { }

  ngOnInit() {

//     this.categories=[{Code:1,Name:'abc',Description:'',Gender:'Male'},
//   {Code:1,Name:'abc',Description:'',Gender:'Female'},
// {Code:1,Name:'abc',Description:'',Gender:'Male'}]

this.categories=this.data.getCategory();
  }

  onCategoryClick(category){
this.router.navigate(['/products',category.name]);
  }

}
