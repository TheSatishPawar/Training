import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Product } from '../_models/product';
import { Observable, throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  private url: string = '/assets/data/product.json';

  constructor(private http: HttpClient) { }

  getproducts(): Observable<Product[]>{
    //return throwError('askdfkasjf');
  return this.http.get<Product[]>(this.url)
  .pipe(catchError(this.handleError));
  }

  handleError(error)
  {
    let errorMessage=error.errorMessage;
    return throwError(errorMessage);
  }

  getCategory(){
    return [
      {cid:1, name:'Juices', description:''},
      {cid:2, name:'Drinks', description:''},
      {cid:3, name:'Milk', description:''}
    ];
  }
}
