import { Component, OnInit } from '@angular/core';
import { DataService } from '../_services/data.service';
import { Product } from '../_models/product';
import {ToastrModule, ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-products-item',
  templateUrl: './products-item.component.html',
  styleUrls: ['./products-item.component.css']
})
export class ProductsItemComponent implements OnInit {

  products:any=[];
  errorMsg:string='';
  constructor(private dataService:DataService, private toaster: ToastrService) { }

  ngOnInit() {
    this.getproducts();
  }

  getproducts(){
  return this.products=this.dataService.getproducts()
   .subscribe((res)=> { 
     console.log(res); 
     this.products= res as Product[];
    }
   ,error=>{console.log('error '+error); this.errorMsg=error;})
  }

  showToaster()
  {
    this.toaster.success('hello')
  }

}
