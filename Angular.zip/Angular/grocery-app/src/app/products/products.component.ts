import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  public categoryName;

  constructor(private route:ActivatedRoute) { 
  let name=  this.route.snapshot.paramMap.get('name');
  this.categoryName=name;
  }

  ngOnInit() {
  }

}
