import { Component, OnInit } from '@angular/core';
import {User} from '../_models/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  hasError:any= true;
  Cities=['Delhi','Mumbai','Pune'];
  constructor() { }

  //userModel = new User('satish',98098098,'abc@abc.com','Mumbai','male',true);
  userModel = new User('',null,'','','',null);

  ngOnInit() {
  }

onChange(value:any)
{
  if(value=="default"){
  this.hasError=true;
  }
  else{
  this.hasError=false;
  }
}

submitForm(data)
{
  console.log(this.userModel);
}

}
