import { Component, OnInit,ViewChild,ViewContainerRef,
ComponentFactoryResolver,ComponentRef,ComponentFactory } from '@angular/core';
import { StudentInfoComponent } from './student-info/student-info.component';
import { ParentInfoComponent } from './parent-info/parent-info.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  message = 'DynamicComponent';

  componetRef:any;

  @ViewChild('loadComponent',{read:ViewContainerRef}) entry: ViewContainerRef;
  constructor(private resolver: ComponentFactoryResolver){}

  data = [
    {
      "Id": 1,
      "Name": "Student Info"
    },
    {
      "Id": 2,
      "Name": "Parent Info"
    }
  ];

  createComponent(Id: number){
this.entry.clear();
if(Id == 1){
  const factory=this.resolver.resolveComponentFactory(StudentInfoComponent);
  this.componetRef=this.entry.createComponent(factory);
}
else if(Id==2){
  const factory=this.resolver.resolveComponentFactory(ParentInfoComponent);
  this.componetRef=this.entry.createComponent(factory);
}

this.componetRef.instance.message="Called by app component";

  }

destroyComponent()
{
  this.componetRef.destroy();
}

  selectName(id: number){
this.createComponent(id);
  }

ngOnInit(){
 // alert(this.message);
}
}
