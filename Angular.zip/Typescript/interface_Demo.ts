interface Dimension{
    x:number;
    y:number;
}

function drawLine(dimension:Dimension){
    //
}

drawLine({x:1,y:2});