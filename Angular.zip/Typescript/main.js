function test(message) {
    console.log(message);
}
var message = 'hello world';
test(message);
