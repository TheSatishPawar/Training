let newMessage="abc";
let newValue=newMessage.endsWith('C');

let newMessage1;

let firstway=(<string> newMessage1).endsWith('c');
let secondWay=(newMessage1 as string).endsWith('c');